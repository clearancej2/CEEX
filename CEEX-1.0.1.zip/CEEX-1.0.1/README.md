# Commons
Some helper functions, dialogs etc used by multiple Fossify apps.</br>
For reporting bugs/features that affect multiple apps please use the <a href="https://github.com/FossifyOrg/General-Discussion">General Discussion</a> repository.
