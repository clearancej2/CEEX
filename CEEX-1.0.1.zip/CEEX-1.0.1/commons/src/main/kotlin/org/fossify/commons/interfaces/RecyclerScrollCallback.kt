package org.fossify.commons.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
