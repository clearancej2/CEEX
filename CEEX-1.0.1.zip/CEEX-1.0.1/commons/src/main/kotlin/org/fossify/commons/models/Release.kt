package org.fossify.commons.models

import androidx.compose.runtime.Immutable

@Immutable
data class Release(val id: Int, val textId: Int)
