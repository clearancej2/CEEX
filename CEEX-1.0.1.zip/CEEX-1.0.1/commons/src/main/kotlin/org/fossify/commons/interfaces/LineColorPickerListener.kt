package org.fossify.commons.interfaces

fun interface LineColorPickerListener {
    fun colorChanged(index: Int, color: Int)
}
