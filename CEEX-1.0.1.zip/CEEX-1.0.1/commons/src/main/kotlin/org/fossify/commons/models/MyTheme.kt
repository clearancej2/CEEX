package org.fossify.commons.models

data class MyTheme(
    val labelId: Int,
    val textColorId: Int,
    val backgroundColorId: Int,
    val primaryColorId: Int,
    val appIconColorId: Int
)
