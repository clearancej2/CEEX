package org.fossify.commons.models

data class RecyclerSelectionPayload(val selected: Boolean)
