package org.fossify.commons.interfaces

interface RefreshRecyclerViewListener {
    fun refreshItems()
}
