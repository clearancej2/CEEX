package org.fossify.commons.helpers

enum class ExportResult {
    EXPORT_FAIL, EXPORT_OK, EXPORT_PARTIAL
}
