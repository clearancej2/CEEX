package org.fossify.commons.models

enum class Android30RenameFormat {
    SAF,
    CONTENT_RESOLVER,
    NONE
}
